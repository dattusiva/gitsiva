# ONERING

![banner](./resources/PACCAR_IT_LogoHorizontalColor2017.jpg)
*ONE RING RULE THEM ALL* -- *ONE EC2 SETUP TO BIND THEM*

![badge](https://img.shields.io/badge/PACCAR-STANDARD-blue)
[![license](https://img.shields.io/github/license/ChuckRichmond/onering)](LICENSE)
[![standard-readme compliant](https://img.shields.io/badge/readme%20style-standard-brightgreen.svg?style=flat-square)](https://github.com/RichardLitt/standard-readme)

This repo is designed to be used as reference for deploying an EC2 image that meets with PACCAR linux standareds.

The intent of this repo is not be used as a primary deployment mechanism but as a resource for techniques to deploy PACCAR Standard images.

## Table of Contents

- [Security](#security)
- [Background](#background)
- [Install](#install)
- [Usage](#usage)
- [API](#api)
- [Contributing](#contributing)
- [License](#license)

## Security

### AWS Access

This repo requires AWS credentials for deployment of the EC2 instances. 

## Background

Standard 664 [^1] gives the basic requirements to secure a linux instance to PACCAR standard. This is a subset of the CIS Benchmark for Linux [^2].

PACCAR has a long practice in maintaining Unix, AIX and Linux in our on-premise data centers, and this project  takes that practice and updates it for cloud and the more common linux variants used in AWS. 


### Any optional sections

TODO: inject the appropriate standard refernces either here or on footnotes.

## Install

### AWS CLI v2

``` bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
lovelyness here.
```

### Terraform

``` bash
wget -qO - terraform.gpg https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/terraform-archive-keyring.gpg
sudo echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/terraform-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" > /etc/apt/sources.list.d/terraform.list
```

### AWS plugin for Session Manager

### Cloud-init linter

### Bash

### perl

## Usage

clone the repo
fork the repo

### Simple deployment pattern

``` bash
terraform plan --var-file <your var file>
terraform apply --var-file <your var file>
terraform delete --var-file <your var file>
```

### Multi-state deployment pattern

``` bash
terraform workspace new <your workspace name>
```

## More optional sections

## Contributing

See [the contributing file](CONTRIBUTING.md)!

PRs accepted.

Small note: If editing the Readme, please conform to the [standard-readme](https://github.com/RichardLitt/standard-readme) specification.

### Any optional sections

## License

[MIT © Chuck Richmond.](../LICENSE)

[^1]: [Standard 664](https://paccar.sharepoint.com/:w:/r/sites/ITD-REFARCH-Document-Site/Reference%20Architecture%20Library/Standard%20655%20-%20UNIX%20Active%20Directory%20Integration.docx?d=w2542a01cb392451d8c277cff9c7fd37e&csf=1&web=1&e=HB5alm)

[^2]: [CIS Benchmark for Linux](https://www.cisecurity.org/cis-benchmarks/)
