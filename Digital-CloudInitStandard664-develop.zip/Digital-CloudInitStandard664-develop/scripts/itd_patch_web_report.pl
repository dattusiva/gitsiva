#!/usr/bin/perl
# Maqsood Ahmed
# ITD  Linux patch report
# April 2022
#######################################

use CGI qw(:standard);
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);

$div=itd;

$PTH="/opt/scripts/admin/lxpatch/${div}";
$DPTH="/opt/apache/htdocs/patchreports/${div}";

chomp ($reportdate=`date +%m/%d/%Y`);
chomp ($curdate=`date +%Y%m`);
chomp ($mnthyear=`date +%B, +%Y`);
print "current date $curdate\n";

$all_list="$PTH/${div}_linux_patch_report_${curdate}";
$test_list="$PTH/${div}_linux_patch_report_${curdate}\.test";
$cert_list="$PTH/${div}_linux_patch_report_${curdate}\.cert";
$prod_list="$PTH/${div}_linux_patch_report_${curdate}\.prod";

print "all_list $all_list\n";

$patch_html="${div}_linux_patch_report_${curdate}\.html";
$all_html_detail="${div}_linux_patch_all_servers_${curdate}\.html";
$test_html_detail="${div}_linux_patch_test_servers_${curdate}\.html";
$cert_html_detail="${div}_linux_patch_cert_servers_${curdate}\.html";
$prod_html_detail="${div}_linux_patch_prod_servers_${curdate}\.html";

print "patch_html $patch_html\n";

open (PATCH_REPORT,">$patch_html");
open (ALLHTML, ">$all_html_detail");
open (TESTHTML, ">$test_html_detail");
open (CERTHTML, ">$cert_html_detail");
open (PRODHTML, ">$prod_html_detail");

open (ALL, "<$all_list");
my @ALLSys=<ALL>;
close (ALL);

open (TEST, "<$test_list");
my @TESTSys=<TEST>;
close (TEST);

open (CERT, "<$cert_list");
my @CERTSys=<CERT>;
close (CERT);

open (PROD, "<$prod_list");
my @PRODSys=<PROD>;
close (PROD);

print PATCH_REPORT "<BODY BGCOLOR=\"#CCCCCC\">\n";
     print header;
       print start_html('Get Reports');
       
        my $red = '<font size="2" color="red">';
	#	my $endfont='</font>';
		my $blue = '<font size="2" color="blue">';
		my $purple = '<font size="3" color="purple">';
		my $green = '<font size="2" color="green">';
print PATCH_REPORT"<table border><tr><th></tr></th>\n";
print PATCH_REPORT "<table border><tr><th>PACCAR <IMG SRC\=\"\paccar_header.jpg\" ALIGN\=LEFT WIDTH\=150 HEIGHT\=22> $div Linux Servers Patching Report</tr></th>\n";
print PATCH_REPORT "<table border><tr><td>Report Date: $reportdate </td></th></tr>\n";
print PATCH_REPORT "<table border><tr><td>Patch report for: $mnthyear</td></th></tr>\n";
print PATCH_REPORT "<table border><tr><td>$div Test/Cert/Prod servers are patched 1st/2nd/3rd Saturday of the month</td></th></tr>\n";
print ALLHTML "<BODY BGCOLOR=\"#CCCCCC\">\n";
     print header;
 print ALLHTML "<script src=\"sorttable.js\"></script>\n";
          print start_html('Get Reports');
       
	        my $red = '<font size="2" color="red">';
		#my $endfont='</font>';
		my $blue = '<font size="2" color="blue">';
		my $purple = '<font size="3" color="purple">';
		my $green = '<font size="2" color="green">';
print ALLHTML"<table border><tr><th></tr></th>\n";
print ALLHTML "<table border><tr><th>PACCAR <IMG SRC\=\"\paccar_header.jpg\" ALIGN\=LEFT WIDTH\=150 HEIGHT\=22>$div All Linux servers Patching report</tr></th>\n";
print ALLHTML "<table class\=\"sortable\" id\=\"nofull\" cellpadding=\"5\">\n";
print ALLHTML "<TR><TD>Count</TD><TD>Server Name</TD><TD>OS</TD><TD>Online</td><TD>Status</TD><TD>Patches Due</TD></TR>\n";

#####################   ALL  servers   ############################
$acount=0;
$apcount=0;
$count=0;

foreach $allservers(@ALLSys) {
	next if ($allservers =~ /Server/i);
	#print "allservers $allservers\n";
	
	($aserver,$aos,$aonline,$astat,$apatches) = split (/\,/,$allservers);
	$apatches =~ s/^\s+|\s+$//g;
	chomp ($aserver);
	chomp ($aos);
	chomp($aonline);
	chomp ($astat);
	chomp ($apatches);
$count++;
#	print "$aserver|$aos|$aonline|$astat|$apatches\n";
print ALLHTML "<tr><td>$blue $count</td><td><a href=\"http:\/\/ittracker.paccar.com\/ittracker\/User_View\/Server_ServiceLevel\/Server_Display.asp?ServNM=$aserver\">$blue $aserver</td><td>$blue $aos</td><td>$blue $aonline</td><td>$blue $astat</td><td>$blue $apatches</td></tr>$endfont\n";

	if ( $apatches !=0) {
		$apcount++;
	}
	$acount++;
}

#print "acount $acount\n";
#print "apatched $apcount\n";
#$prcnt_ptch=(($acount-$apcount)/$acount*100);
#$prcnt_ptch_rounded=sprintf("%.0f",$prcnt_ptch);

if ( $acount !=0) {
$prcnt_ptch=(($acount-$apcount)/$acount*100);
$prcnt_ptch_rounded=sprintf("%.0f",$prcnt_ptch);
  }
else {
$prcnt_ptch_rounded=0;
}
if ($prcnt_ptch_rounded <99 ) {
print PATCH_REPORT "<tr><td><h2>$blue $div  All servers percent patched: $red $prcnt_ptch_rounded% <a href=$all_html_detail> $blue Details </a></h2></tr>$endfont\n";
 }
else {
print PATCH_REPORT "<tr><td><h2>$blue $div  All servers percent patched: $green $prcnt_ptch_rounded% <a href=$all_html_detail> $blue Details </a></h2></tr>$endfont\n";
  }
 

###################  Test Servers   ###############################

print TESTHTML "<BODY BGCOLOR=\"#CCCCCC\">\n";
     print header;
print TESTHTML "<script src=\"sorttable.js\"></script>\n";
          print start_html('Get Reports');
       
       		 my $red = '<font size="2" color="red">';
		#my $endfont='</font>';
		my $blue = '<font size="2" color="blue">';
		my $purple = '<font size="3" color="purple">';
		my $green = '<font size="2" color="green">';
print TESTHTML"<table border><tr><th></tr></th>\n";
print TESTHTML"<table border><tr><th></tr></th>\n";
print TESTHTML "<table border><tr><th>$div Test Linux servers Patching report</tr></th>\n";
print TESTHTML "<table class\=\"sortable\" id\=\"nofull\" cellpadding=\"5\">\n";
print TESTHTML "<TR><TD>Count</TD><TD>Server Name</TD><TD>OS</TD><TD>Online</td><TD>Status</TD><TD>Patches Due</TD></TR>\n";
$ttcount=0;
$tpcount=0;
$count=0;
foreach $Tservers(@TESTSys) {
	next if ($Tservers =~ /Server/i);
	#print "Tservers $Tservers\n";
	
	($tserver,$tos,$tonline,$tstat,$tpatches) = split (/\,/,$Tservers);
	$tpatches =~ s/^\s+|\s+$//g;
	chomp ($tserver);
	chomp ($tos);
	chomp($tonline);
	chomp ($tstat);
	chomp ($tpatches);
$count++;
#	print "$tserver|$tos|$tonline|$tstat|$tpatches\n";
print TESTHTML "<tr><td>$blue $count</td><td><a href=\"http:\/\/ittracker.paccar.com\/ittracker\/User_View\/Server_ServiceLevel\/Server_Display.asp?ServNM=$tserver\">$blue $tserver</td><td>$blue $tos</td><td>$blue $tonline</td><td>$blue $tstat</td><td>$blue $tpatches</td></tr>$endfont\n";

	if ( $tpatches !=0) {
		$tpcount++;
	}
	$ttcount++;
}

#print "ttcount $ttcount\n";
#print "tpatched $tpcount\n";
#$tprcnt_ptch=(($ttcount-$tpcount)/$ttcount*100);
#$tprcnt_ptch_rounded=sprintf("%.0f",$tprcnt_ptch);
if ( $ttcount !=0) {
$tprcnt_ptch=(($ttcount-$tpcount)/$ttcount*100);
$tprcnt_ptch_rounded=sprintf("%.0f",$tprcnt_ptch);
  }
else {
$tprcnt_ptch_rounded=0;
}
if ($tprcnt_ptch_rounded <99 ) {
print "TEST percent patched $tprcnt_ptch_rounded\n";
print PATCH_REPORT "<tr><td><h2>$blue $div Test Linux servers percent patched $red $tprcnt_ptch_rounded% <a href=$test_html_detail> $blue Details </a></h2></tr>$endfont\n";
  }
 else {
print PATCH_REPORT "<tr><td><h2>$blue $div Test Linux servers percent patched $green $tprcnt_ptch_rounded% <a href=$test_html_detail> $blue Details </a></h2></tr>$endfont\n";
  }
###################  Cert Servers   #############################

print CERTHTML "<BODY BGCOLOR=\"#CCCCCC\">\n";
     print header;
print CERTHTML "<script src=\"sorttable.js\"></script>\n";
          print start_html('Get Reports');
       
	        my $red = '<font size="2" color="red">';
		#my $endfont='</font>';
		my $blue = '<font size="2" color="blue">';
		my $purple = '<font size="3" color="purple">';
		my $green = '<font size="2" color="green">';
print CERTHTML"<table border><tr><th></tr></th>\n";
print CERTHTML"<table border><tr><th></tr></th>\n";
print CERTHTML "<table border><tr><th>$div Cert Linux servers Patching report</tr></th>\n";
print CERTHTML "<table class\=\"sortable\" id\=\"nofull\" cellpadding=\"5\">\n";
print CERTHTML "<TR><TD>Count</TD><TD>Server Name</TD><TD>OS</TD><TD>Online</td><TD>Status</TD><TD>Patches Due</TD></TR>\n";

$ctcount=0;
$cpcount=0;
$count=0;
foreach $Cservers(@CERTSys) {
	next if ($Cservers =~ /Server/i);
	#print "Cservers $Cservers\n";
	
	($cserver,$cos,$conline,$cstat,$cpatches) = split (/\,/,$Cservers);
	$cpatches =~ s/^\s+|\s+$//g;
	chomp ($cserver);
	chomp ($cos);
	chomp($conline);
	chomp ($cstat);
	chomp ($cpatches);
$count++;
#	print "$cserver|$cos|$conline|$cstat|$cpatches\n";
print CERTHTML "<tr><td>$blue $count</td><td><a href=\"http:\/\/ittracker.paccar.com\/ittracker\/User_View\/Server_ServiceLevel\/Server_Display.asp?ServNM=$cserver\">$blue $cserver</td><td>$blue $cos</td><td>$blue $conline</td><td>$blue $cstat</td><td>$blue $cpatches</td></tr>$endfont\n";
	if ( $cpatches !=0) {
		$cpcount++;
	}
	$ctcount++;
}

#print "ctcount $ctcount\n";
#print "cpatched $cpcount\n";

if ( $ctcount !=0 ) {
$cprcnt_ptch=(($ctcount-$cpcount)/$ctcount*100);
$cprcnt_ptch_rounded=sprintf("%.0f",$cprcnt_ptch);
  }
else {
$cprcnt_ptch_rounded=0;
 }
if ($cprcnt_ptch_rounded <99 ) {
print "CERT percent patched $cprcnt_ptch_rounded\n";
print PATCH_REPORT "<tr><td><h2>$blue $div Cert servers percent patched $red $cprcnt_ptch_rounded%<a href=$cert_html_detail>$blue Details </a></h2></tr>$endfont\n";
  }
else {
print PATCH_REPORT "<tr><td><h2>$blue $div Cert servers percent patched $green $cprcnt_ptch_rounded%<a href=$cert_html_detail>$blue Details </a></h2></tr>$endfont\n";
  }
######################  PROD Servers   ###############################

print PRODHTML "<BODY BGCOLOR=\"#CCCCCC\">\n";
     print header;
 print PRODHTML "<script src=\"sorttable.js\"></script>\n";
          print start_html('Get Reports');
       
        my $red = '<font size="2" color="red">';
		#my $endfont='</font>';
		my $blue = '<font size="2" color="blue">';
		my $purple = '<font size="3" color="purple">';
		my $green = '<font size="2" color="green">';
print PRODHTML"<table border><tr><th></tr></th>\n";
print PRODHTML"<table border><tr><th></tr></th>\n";
print PRODHTML "<table border><tr><th>$div Prod Linux servers Patching report</tr></th>\n";
print PRODHTML "<table class\=\"sortable\" id\=\"nofull\" cellpadding=\"5\">\n";
print PRODHTML "<TR><TD>Count</TD><TD>Server Name</TD><TD>OS</TD><TD>Online</td><TD>Status</TD><TD>Patches Due</TD></TR>\n";

$ptcount=0;
$ppcount=0;
$count=0;
foreach $Pservers(@PRODSys) {
	next if ($Pservers =~ /Server/i);
	#print "Pservers $Pservers\n";
	
	($pserver,$pos,$ponline,$pstat,$ppatches) = split (/\,/,$Pservers);
	$ppatches =~ s/^\s+|\s+$//g;
	chomp ($pserver);
	chomp ($pos);
	chomp($ponline);
	chomp ($pstat);
	chomp ($ppatches);
$count++;
#	print "$pserver|$pos|$ponline|$pstat|$ppatches\n";
print PRODHTML "<tr><td>$blue $count</td><td><a href=\"http:\/\/ittracker.paccar.com\/ittracker\/User_View\/Server_ServiceLevel\/Server_Display.asp?ServNM=$pserver\">$blue $pserver</td><td>$blue $pos</td><td>$blue $ponline</td><td>$blue $pstat</td><td>$blue $ppatches</td></tr>$endfont\n";
	if ( $ppatches !=0) {
		$ppcount++;
	}
	$ptcount++;
}

#print "ptcount $ptcount\n";
#print "ppatched $ppcount\n";
#$pprcnt_ptch=(($ptcount-$ppcount)/$ptcount*100);
#$pprcnt_ptch_rounded=sprintf("%.0f",$pprcnt_ptch);
print "PROD percent patched $pprcnt_ptch_rounded\n";
if ( $ptcount !=0) {
$pprcnt_ptch=(($ptcount-$ppcount)/$ptcount*100);
$pprcnt_ptch_rounded=sprintf("%.0f",$pprcnt_ptch);
  }
else {
$pprcnt_ptch_rounded=0;
}
if ($pprcnt_ptch_rounded <99 ) {
print PATCH_REPORT "<tr><td><h2>$blue $div Prod servers percent patched $red $pprcnt_ptch_rounded%<a href=$prod_html_detail>Details</a></h2></tr>$endfont\n";
  } 
else {
print PATCH_REPORT "<tr><td><h2>$blue $div Prod servers percent patched $green $pprcnt_ptch_rounded%<a href=$prod_html_detail>Details</a></h2></tr>$endfont\n";
  }
print "ALL percent patched $prcnt_ptch_rounded\n";

close (ALLHTML);
close (PATCH_REPORT);
close (TESTHTML);
close (CERTHTML);
close (PRODHTML);

#system ("cp $patch_html /opt/apache/htdocs/patchreports");
#system ("cp $all_html_detail /opt/apache/htdocs/patchreports");
#system ("cp $test_html_detail /opt/apache/htdocs/patchreports");
#system ("cp $cert_html_detail /opt/apache/htdocs/patchreports");
#system ("cp $prod_html_detail /opt/apache/htdocs/patchreports");

system ("mv $patch_html $DPTH");
system ("mv $all_html_detail $DPTH");
system ("mv $test_html_detail $DPTH");
system ("mv $cert_html_detail $DPTH");
system ("mv $prod_html_detail $DPTH");
