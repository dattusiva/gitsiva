#!/usr/bin/perl
#
#
#
#  Script to run Intrusion Detection on the system
#
#  Maqsood Ahmed
#  PACCAR Inc
#  April 11, 2018
#
# 06/18/20 - JRN - Added hostname to email subject.
##############################################################
#
chomp ($RPTDATE=`date +%Y%m%d`);
chomp ($DATE=`date`);
chomp ($HOSTNAME=`hostname`);
$AIDEDIR='/var/log/aide';
$AIDELOG='/var/log/aide/aide.log';
$LOG='/opt/scripts/admin/aidechk.log';
$ADDRESSEE="itdrentonunixadmins\@paccar.com";

 if ( ! -d $AIDEDIR ) {
  `mkdir -p $AIDEDIR`;
 }

open (TLOG,">$LOG");

 system("cat /etc/*release* \|grep -i -E \"(red hat|Amazon Linux|ubuntu)\"");
   if ($? == 0) {
$bin="/usr/sbin";
$dbnew="/var/lib/aide/aide.db.new.gz";
$db="/var/lib/aide/aide.db.gz";
   }
else 
  {
$bin="/usr/bin";
$dbnew="/var/lib/aide/aide.db.new";
$db="/var/lib/aide/aide.db";
  }
print "bin $bin\n";
print "db $db\n"; 
print "dbnew $dbnew\n"; 

#Check if aide check is not already running ... 
$chkaid="ps -ef \|grep -v grep \|grep \"aide \-\-check\"";
system ("$chkaid");
  if ($? eq 0) {
print TLOG "aide check running - will try later\n";
exit 0;
  }

#Check if db init is running... 
$chkinit="ps -ef \|grep -v grep \|grep \"aide -i\"";
system ("$chkinit");
  if ($? eq 0) {
print TLOG "aide init running - will try later\n";
  exit 0;
   }

# Run aide check
`$bin/aide --check -V`;

  open (LOG,"<$AIDELOG");
   my @MSG=<LOG>;
  close (LOG);
foreach $file(@MSG) {
 if ($file =~ /File\:/) {
($F,$filename) = split (/\:/,$file);
$filename =~ s/^\s+//;
next if ($filename =~ /\/etc\/aide\.conf/);
chomp ($filename);
print TLOG "bef $filename\n";
if (-x $filename) {
print TLOG "Modified executable file $filename\n";
system ("echo AIDE: Modified executable file $filename \|mailx -s \"$HOSTNAME AIDE: Modified execuatable file $filename\" $ADDRESSEE");
`/opt/scripts/admin/snmp2scom.ksh "AIDE: Modified executable file $filename"`;
  }
elsif ($filename =~ /etc/) {
print TLOG "Modified  $filename\n";
system ("echo AIDE: Modified file $filename \|mailx -s \"$HOSTNAME AIDE: Modified file $filename\" $ADDRESSEE");
`/opt/scripts/admin/snmp2scom.ksh "AIDE: Modified file $filename"`;
   }
  }
}
#Backup  log
system ("cp $AIDELOG $AIDELOG.$RPTDATE");
# Init AIDE db 
`$bin/aide -i`;
# move db
`mv $dbnew $db`;
exit;
close TLOG;
