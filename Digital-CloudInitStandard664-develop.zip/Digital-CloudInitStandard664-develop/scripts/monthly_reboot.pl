#!/usr/bin/perl
######-########################################################################
######- Script Name:  monthly_reboot.pl
######- Purpose:      Script to reboot server after patching is complete
######- Called by:    cron
######- Calls:
######- Author:       Maqsood Ahmed
######- Created:      March 21st 2018
####### Revision History:
####### Date     Analyst  Description
####### ----     -------  --------------------------------------------------
####### 8/23/19   JRN     Converted separate scripts into a single script that
#######                   accepts a week number to determine if the system 
#######                   should be rebooted.
####### 01/31/22  MA	  Reboot server regardless of patch completion.  
#######		          Send email out with outstanding patches due. 
####### 02/22/22  JRN	  Adding permission change for /etc/cron.d and any files
#######                   under that directory for 664 compliance after patching
###############################################################################

$WEEK = $ARGV[0];
# Make sure we are passing a 1, 2 or 3.  If not, exit.
if ("$WEEK" !~ /[1-3]/) {
   print "Invalid parameter!!!  This script requires a week number (i.e. 2 for second week)" ;
  system("echo Reboot script called with an invalid paramater = $WEEK!!! \| mailx \-s \"Bad reboot call on `hostname`!!!\" itdrentonunixadmins\@paccar.com") ;
   exit 999;
}

$logfile='/opt/scripts/admin/logs/server_reboot.log';
chomp ($HOST=`hostname`);
chomp ($DATE=`date`);
chomp ($DATER=`date +%Y%m%d`);
open (LOG, ">$logfile");
print LOG "===================================================\n";
print LOG "\n";
print LOG "Server $HOST reboot log\n";
print LOG "Date:  $DATE\n";
print LOG "\n";
print LOG "===================================================\n";

#  Use HEAD_NUM to get the proper week from the "cal" command
$HEAD_NUM = `expr 2 + $WEEK`;
chomp ($HEAD_NUM);

$Sat = "/usr/bin/cal \|head \-$HEAD_NUM \|tail \-1 \|awk '{print \$NF}'";

chomp ($today = `date +%d`);
open (RSat, "$Sat|");
  while (<RSat>) {
  chomp ($RebootSat = $_);
if ($today != $RebootSat) {
print LOG  "Today: $today\n";
print LOG "Reboot Sat: $RebootSat\n";
print LOG "Not the Proper Saturday. Not rebooting today. \n";
print LOG "\n";
print LOG "===================================================\n";
exit 0;
 }
}
system("cat /etc/*release* \|grep  \'ID\=\"rhel\"\'");
if ($? == 0) {
`yum updateinfo list |grep "^RH" |awk '{print \$1}' |sort |uniq |wc -l >/tmp/ptch.out`;
 }
else {
`zypper lp |grep CL-SUSE |wc -l >/tmp/ptch.out`;
  }
open (PTCH,"</tmp/ptch.out");
while (<PTCH>) {
chomp ($patchdue=$_);
if ($patchdue >0) {
print LOG "Today: $today\n";
print LOG "Reboot Sat: $RebootSat\n";
print LOG "Today is the Proper Saturday. Okay to reboot...  \n";
print LOG "No of patches: $patchdue still due on $HOST.  Proceeding with reboot\n";
system ("echo No of patches\: $patchdue still due on $HOST.  Proceeding with reboot...  \|mailx \-s \"Linux Patch report\" itdrentonunixadmins\@paccar.com");
`sleep 30`;
print LOG "\n";
print LOG "===================================================\n";
`/usr/bin/chmod o-rx /etc/cron.d`;
`/usr/bin/chmod o-r /etc/cron.d/*`;
`/usr/bin/rm /tmp/ptch.out`;
system ("/sbin/shutdown -r now"); 

 }
else {
print LOG "Today: $today\n";
print LOG "Reboot Sat: $RebootSat\n";
print LOG "Today is the Proper Saturday. Okay to reboot...  \n";
print LOG "No of patches: $patchdue due on $HOST...  \n";
print LOG "Proceeding with $HOST reboot...\n";
print LOG "\n";
print LOG "===================================================\n";
`/usr/bin/chmod o-rx /etc/cron.d`;
`/usr/bin/chmod o-r /etc/cron.d/*`;
`/usr/bin/rm /tmp/ptch.out`;
system ("/sbin/shutdown -r now"); 
  }
 } 
close RHN;
close RSat;
close LOG;
close PTCH;
