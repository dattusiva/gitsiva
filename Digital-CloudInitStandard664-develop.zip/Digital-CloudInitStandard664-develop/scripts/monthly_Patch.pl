#!/usr/bin/perl
######-########################################################################
######- Script Name:  monthly_Patch.pl
######- Purpose:      Script to start the PATCHING on local server
######- Called by:    cron
######- Calls:
######- Author:       Maqsood Ahmed
######- Created:      March 21st 2018
####### Revision History:
####### Date     Analyst  Description
####### ----     -------  --------------------------------------------------
####### 8/23/19   JRN     Converted separate scripts into a single script that
#######                   accepts a week number to determine if the system 
#######                   should be patched.
####### 3/26/21   JRN     Turn off AIDE prior to patching and then 
#######                   re-create the aide.db after patching is complete to 
#######                   limit AIDE alerts caused by patches
###############################################################################

$WEEK = $ARGV[0];
## Make sure we are passing a 1, 2 or 3.  If not, exit.
if ("$WEEK" !~ /[1-3]/) {
   print "Invalid parameter!!!  This script requires a week number (i.e. 2 for second week)" ;
   system("echo Patch script called with an invalid paramater = $WEEK!!! \| mailx \-s \"Bad patch call on `hostname`!!!\" itdrentonunixadmins\@paccar.com") ;
   exit 999;
}

system("cat /etc/*release* \|grep -i \"red hat\"");
if ($? == 0) {
   $bin="/usr/sbin";
   $dbnew="/var/lib/aide/aide.db.new.gz";
   $db="/var/lib/aide/aide.db.gz";
   }
else
  {
   $bin="/usr/bin";
   $dbnew="/var/lib/aide/aide.db.new";
   $db="/var/lib/aide/aide.db";
  }

$logfile='/opt/scripts/admin/logs/server_patching.log';
chomp ($HOST=`hostname`);
chomp ($DATE=`date`);
chomp ($DATER=`date +%Y%m%d`);
open (LOG, ">$logfile.$DATER");
print LOG "===================================================\n";
print LOG "\n";
print LOG "Server $HOST PATCHING log\n";
print LOG "Date:  $DATE\n";
print LOG "\n";
print LOG "===================================================\n";

$rhn="ps -ef \|grep -v grep \|grep yum";
##  Use HEAD_NUM to get the proper week from the "cal" command
$HEAD_NUM = `expr 2 + $WEEK`;
chomp ($HEAD_NUM);

$Sat = "/usr/bin/cal \|head \-$HEAD_NUM \|tail \-1 \|awk '{print \$NF}'";
chomp ($today = `date +%d`);
open (PSat, "$Sat|");
  while (<PSat>) {
  chomp ($PatchSat = $_);
if ($today != $PatchSat) {
print LOG  "Today: $today\n";
print LOG "Patch Sat: $PatchSat\n";
print LOG "Not Proper Saturday. Not PATCHING today. \n";
print LOG "\n";
print LOG "===================================================\n";
exit 0;
 }
}
system ("$rhn");
if ($? eq 0) {
print LOG "Today: $today\n";
print LOG "Patch Sat: $PatchSat\n";
print LOG "Today Proper Saturday. Okay to PATCH...  \n";
print LOG "PATCHING process is already running on $HOST.  Not PATCHING\n";
system ("echo $HOST not PATCHED...  yum already running \|mailx \-s \"$HOST not PATCHED. yum already running.\" itdrentonunixadmins\@paccar.com");
print LOG "\n";
print LOG "===================================================\n";
exit 1;
}
else {
print LOG "Today: $today\n";
print LOG "Patch Sat: $PatchSat\n";
print LOG "Today is Proper Saturday. Okay to PATCH...  \n";
print LOG "PATCHING process yum is not running...  \n";
print LOG "Proceeding with $HOST PATCHING...\n";
print LOG "\n";
print LOG "===================================================\n";

## Stop AIDE from scanning
print LOG "Removing AIDE cron entry\n";
system ("/usr/bin/crontab -l > /root/crontab.root"); 
system ("/usr/bin/crontab -l |grep -v aidecheck.pl > /root/crontab.root.tmp");
system ("/usr/bin/crontab /root/crontab.root.tmp");
system ("ps -ef \|grep -v grep \|grep aide");
if ($? eq 0) {
   print LOG "Waiting 120 seconds for aide scan to complete\n";
   `sleep 120`;
  }

print LOG "Removing AIDE database prior to patching\n";
system ("rm $db"); 

system ("/usr/bin/yum -y update"); 

# Init AIDE db
system ("$bin/aide -i");
# move db
system ("mv $dbnew $db");

## Return AIDE to cron
print LOG "Restoring aide into cron for root\n";
system ("/usr/bin/crontab /root/crontab.root"); 
system ("rm /root/crontab.root /root/crontab.root.tmp"); 
  }
close RHN;
close PSat;
close LOG;
