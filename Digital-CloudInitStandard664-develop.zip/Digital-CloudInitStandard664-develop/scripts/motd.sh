#! /bin/sh
cat << EOF
                      COMPUTER USAGE POLICY STATEMENT

PACCAR's email, Internet and computer systems are provided for business
purposes and are subject to PACCAR's policy for the proper use of these systems,
which may be found at PACCAR Standard Policy - SP28
http://teamservices.paccar.com/sites/PACCARSPB/Administration/SP28%20Electronic%20Communication%20Guidelines.pdf
Any violation of SP 28 may result in discipline, up to and including termination.

PACCAR absolutely prohibits any use of these systems to prepare, store, access or send
any harassing, obscene, offensive, or illegal communications or materials for any reason

All incoming and outgoing Email, internet activity, social media activity, documents,
spreadsheets, databases, or other computer communications and materials, whether
PACCAR provided or private web-based communications accessed using PACCAR equipment,
are subject to automatic monitoring by computer software and may also be reviewed by
PACCAR personnel at any time and for any lawful reason.

PACCAR (or its relevant subsidiary) will comply with any applicable national data
protection or access laws in conducting its monitoring and review.  By using any PACCAR
computer system, you consent to this monitoring and review.

If PACCAR discovers any evidence of criminal activity, it will provide that evidence to
the appropriate law enforcement authorities. All information stored on PACCAR's computer
systems is the property of PACCAR and is subject to all the protections accorded to
PACCAR's intellectual property and proprietary information.

-----------------------------------------------------------------------------
EOF
