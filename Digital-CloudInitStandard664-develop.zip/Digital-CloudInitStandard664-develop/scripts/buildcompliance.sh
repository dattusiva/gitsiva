#! /bin/bash
# 4.2.1 item 4
sudo chown root:root /var/log/btmp
sudo chmod 660 /var/log/btmp

# git files from Git :)
mkdir -p /opt/scripts/admin
cd /opt/scripts/admin
chmod +x *

# fix the test for the invalid user shells.

# install ClamAV
curl -O http://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum install epel-release-latest-7.noarch.rpm

sudo yum install clamav clamd -y

sudo sed -i -e "s/Example/#Example/" /etc/freshclam.conf
sudo sed -i -e "s:#DatabaseDirectory /var/lib/clamav:DatabaseDirectory /var/lib/clamav:" /etc/freshclam.conf
sudo sed -i -e "s:#UpdateLogFile /var/log/freshclam.log:UpdateLogFile /var/log/freshclam.log:" /etc/freshclam.conf
sudo sed -i -e "s/#DatabaseOwner clamupdate/DatabaseOwner clamupdate/" /etc/freshclam.conf

sudo freshclam
sudo touch /etc/clamd.conf
# aide so maybe
sudo yum install aide
# need aide config and schedule.

# update MOTD
cp motd /etc/update-motd.d/25-paccar
sudo chmod 750 /etc/update-motd.d/25-paccar
cp motd /etc/update-motd.d/26-itd
sudo chmod 750 /etc/update-motd.d/26-itd
# more beautiful stuff from MAK
#Fix
#install ksh
chmod 600 /var/log/btmp
chmod 600 /etc/shadow
chmod 600 /root/.profile
chmod 600 /root/.bashrc
chmod 600 /home/ssm-user/.bashrc
chmod 600 /home/ec2-user/.bashrc
chmod 644 /home/crichmond/.profile
chmod 644 /home/crichmond/.bashrc
chmod 600 /var/spool/cron/tabs
chmod 750 /etc/cron.d
chmod 750 /etc/cron.d/*
chmod 640 /etc/cron.d/atop
chmod 640 /etc/cron.d/e2scrub_all
chmod 644 /etc/shadow
chmod u=rwx,g=rx /root
#check /etc/securetty and remove console
#yum install aide
#Install or use scan tool
#cron job to scan
#install motd in etc (I can send you banner file)
#yum install chrony or ntp and add cronons.paccar.com in config file
cat <<EOF>> /etc/profile.d/500-paccar.sh
TMOUT=3600
export TMOUT
EOF
chmod 750 /etc/profile.d/500-paccar.sh

#yum install openssh-clients
#yum install openssh-server
