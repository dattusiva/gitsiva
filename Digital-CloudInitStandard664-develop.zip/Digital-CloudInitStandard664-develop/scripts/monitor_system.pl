#!/usr/bin/perl
#
# Script to montitor filesystem and  swap send alert 
#
# Maqsood Ahmed
# PACCAR Inc,
# September, 20th 2020
#
#
######################################################
$path="/opt/scripts/admin";
$ctlfile="$path/filesystem.ctl";

my $os = $^O;
my $host=`hostname`;

#Prod Warning and Critical Threshold
$Pwarn=90;
$Pcrit=95;

#NonProd Warning and Critical Threshold
$NPwarn=95;
$NPcrit=98;

chomp ($DATE=`date +%d`);
chomp ($TIME=`date +%H%M`);
 
local $" = '|',
my @phost = (itdp,kwcchlp,kwmvp,kwmp,kwcsttvp,kwcsttp,pbcp,ehvp,leyp);
my $prodhost = "@phost";

open (CTL, "<$ctlfile");
my @fsctl =<CTL>; 
close CTL;

$NONROOTFS="$path/nonr.out";
$EXCLFS="$path/excl.out";
$ADMIN="$path/admin.out";
$NADMIN="$path/nadmin.out";

open (EX,">$EXCLFS");
open (ADM,">$ADMIN");
open (NADM,">$NADMIN");
open (NR,">$NONROOTFS");

foreach $filesys(@fsctl) {
next if ($filesys =~ /#/);

if ($filesys =~/unixadmins/) {
($afs,$aci,$aemail) = split (/\|/, $filesys);
$afs =~ s/^\s+|\s+$//g;
chomp ($afs);
chomp ($aci);
chomp ($aemail);
print ADM "$afs|$aci|$aemail\n";
  }

if ($filesys =~/exclude/) {
($xfs,$xci,$xemail) = split (/\|/, $filesys);
$exfs =~ s/^\s+|\s+$//g;
chomp ($xfs);
chomp ($xci);
chomp ($xemail);
print  EX "$xfs\n";
  }

if ($filesys !~ /exclude|unixadmins/) {
($fs,$ci,$email) = split (/\|/, $filesys);
$fs =~ s/^\s+|\s+$//g;
chomp ($fs);
chomp ($ci);
chomp ($email);
print NADM "$fs|$ci|$email\n";
 }
}
close EX; 
close ADM;
close NADM;

open (NADM, "<$NADMIN");
my @nadmin =<NADM>; 
close NADM;

foreach $Nadmin(@nadmin) {
($lfs,$ci,$email) = split (/\|/, $Nadmin);
$lfs =~ s/^\s+|\s+$//g;
chomp ($lfs);
chomp ($ci);
chomp ($email);
if ($os =~/aix/i) {
$nonroot="df \-P \-m \|grep \-iw $lfs\.*  \|awk \'\{print \$1\,\$6\,\$5\}\'";
open (NONROOT,"$nonroot|");
     while (<NONROOT>) {
     chomp ($NRfs=$_);
next if ($NRfs =~ /\:/);
next if ($NRfs =~ /\/\//);
($fdev,$fmount,$used) = split (/\s+/,$NRfs);
($fsuse,$percnt) = split (/\%/,$used);
print  NR "$fmount\n";
if (($fsuse >=$Pwarn) && ($fsuse <$Pcrit) && ($host =~ /$prodhost/i)){

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);
system ("echo WARNING $fm usage is at $newfsuse\%. SCOM IR for $ci \|mailx -s \"$host filesystem WARNING\: $fm\" $email");

system ("/usr/bin/touch $path/$fmount\_sm\_$fsuse\_$DATE");
$mes="WARNING\: $fm usage on UNIX $host is at $newfsuse\%. Please open P4 IR for $ci ";
`/opt/scripts/admin/snmp2scom.ksh "$mes"`;
   }
  }
elsif (($fsuse >=$NPwarn) && ($fsuse <$NPcrit) && ($host !~ /$prodhost/i)){

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);
system ("echo WARNING $fm usage is at $newfsuse\%. \|mailx -s \"$host filesystem WARNING\: $fm\" $email");
system ("/usr/bin/touch $path/$fmount\_sm\_$fsuse\_$DATE");
   }
  }
if (($fsuse >=$Pcrit) && ($host =~ /$prodhost/i)) {

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);

system ("echo CRITICAL  $fm usage is at $newfsuse\%. SCOM IR for $ci  \|mailx -s \"$host filesytem CRITICAL\: $fm\" $email");
system ("/usr/bin/touch $path/$fmount\_sm\_$fsuse\_$DATE");
$mes="CRITICAL\: $fm usage on UNIX $host is at $newfsuse\%. Please open P3 IR for $ci ";
`/opt/scripts/admin/snmp2scom.ksh "$mes"`;
   }
 }
elsif (($fsuse >=$NPcrit) && ($host !~ /$prodhost/i)) {

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);
system ("echo CRITICAL  $fm usage is at $fsuse\%. \|mailx -s \"$host filesystem CRITICAL\: $fm\" $email");
system ("/usr/bin/touch $path/$fmount\_sm\_$fsuse\_$DATE");
    }
    }
   }
  }
if ($os =~/linux/i) {
#Linux
$nonroot="df \-\-output\=source,target,pcent \|grep \-iw $lfs\.*";
open (NONROOT,"$nonroot|");
     while (<NONROOT>) {
     chomp ($NRfs=$_);
next if ($NRfs =~ /\:/);
next if ($NRfs =~ /\/\//);
($fdev,$fmount,$used) = split (/\s+/,$NRfs);
($fsuse,$percnt) = split (/\%/,$used);
print  NR "$fmount\n";
if (($fsuse >=$Pwarn) && ($fsuse <$Pcrit) && ($host =~ /$prodhost/i)){

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);
system ("echo WARNING  $fm usage is at $newfsuse\%. SCOM IR for $ci  \|mailx -s \"$host filesystem WARNING\: $fm\" $email");
system ("/usr/bin/touch $path/$fmount\_sm\_$newfsuse\_$DATE");
$mes="WARNING\: $fm usage on UNIX $host is at $newfsuse\%. Please open P4 IR for $ci";
`/opt/scripts/admin/snmp2scom.ksh "$mes"`;
   }
 }
elsif (($fsuse >=$NPwarn) && ($fsuse <$NPcrit) && ($host !~ /$prodhost/i)){

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);

system ("echo WARNING  $fm usage is at $newfsuse\%.  \|mailx -s \"$host filesystem WARNING\: $fm\" $email");
system ("/usr/bin/touch $path/$fmount\_sm\_$newfsuse\_$DATE");
   }
 }
if (($fsuse >=$Pcrit) && ($host =~ /$prodhost/i)) {

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);

system ("echo CRITICAL  $fm usage is at $newfsuse\%. SCOM IR for $ci \|mailx -s \"$host filesystem CRITICAL\: $fm\" $email");
system ("/usr/bin/touch $path/$fmount\_sm\_$newfsuse\_$DATE");
$mes="CRITICAL\: $fm usage on UNIX $host is at $newfsuse\%. Please open P3 IR for $ci";
`/opt/scripts/admin/snmp2scom.ksh "$mes"`;
   }
 }
elsif (($fsuse >=$NPcrit) && ($host !~ /$prodhost/i)) {

chomp ($fm=$fmount);
 $fmount  =~ s/\//\_/g;
 chomp $fmount;
$fcmd=`ls -l $path/$fmount\_\* \|awk \'\{print \$9\}\'`;
if ($fcmd !~ "$path/$fmount\_sm\_$fsuse\_$DATE") {
`rm $fcmd `;
next if ($fcmd =~ /$path\/$fmount\_sm\_$fsuse\_$DATE/);
chomp ($newfsuse=$fsuse);
system ("echo CRITICAL  $fm usage is at $newfsuse\%. \|mailx -s \"$host filesystem CRITICAL\: $fm\" $email");
system ("/usr/bin/touch $path/$fmount\_sm\_$newfsuse\_$DATE");
     }
    }
   }
  }
 }
##############################  root filesystem ###########################
$ROOTFS="/$path/rfs.out";
open (RFs,">$ROOTFS");

$ALLFS="df -P  \|grep \-v grep \|grep \-v Filesys  \|awk '\{print \$1 \" \" \$6\}'";
open (X, "<$EXCLFS");
my @exclfs =<X>;
chomp (@exclfs);
close X;
$exfs = join("|",@exclfs);
$exfs =~ s/^\s+|\s+$//g;
chomp ($exfs);

open (R,"$ALLFS|");
   while (<R>){
      chomp ($AllFS=$_);
next if ($AllFS =~ /\:/);
next if ($AllFS =~ /\/\//);
($filesystem, $mpoint) = split (/\s+/,$AllFS);
next if ($mpoint =~ /$exfs/i);
chomp ($mpoint);
      print  RFs "$mpoint\n";
   }
close R;
system ("sort -\k1  $NONROOTFS \>$NONROOTFS.s");
system ("sort -\k1  $ROOTFS \>$ROOTFS.s");
system ("join \-v1 \-v2 $NONROOTFS.s $ROOTFS.s \>\/$path\/rootfs.out");
open (RFS,"</$path/rootfs.out");
   my @allfs =<RFS>;
   close RFS;
foreach $allfilesys(@allfs) {
chomp ($allfilesys);
$root="df -P $allfilesys \|grep \-v Filesys \|awk '\{print \$5\}'";
open (ROOT,"$root|");
     while (<ROOT>) {
     chomp ($Rfs=$_);
($rfsuse,$rpercnt) = split (/\%/,$Rfs);

if (($rfsuse >=$Pwarn) && ($rfsuse <$Pcrit) && ($host =~ /$prodhost/i) ){
#print "PROD WARN \n";
 chomp ($afs=$allfilesys);
 $allfilesys  =~ s/\//\_/g;
 chomp $allfilesys;
$cmd=`ls -l $path/$allfilesys\_\* \|awk \'\{print \$9\}\'`;
if ($cmd !~ "$path/$allfilesys\_sm\_$rfsuse\_$DATE") {
`rm $cmd `;
next if ($cmd =~ /$path\/$allfilesys\_sm\_$rfsuse\_$DATE/);
chomp ($newrfsuse=$rfsuse);
#print "AFS PROD $afs\n";
#if ($afs !~ /\/var\/gis/) {
if (($afs !~ /\/var\/gis/) || ($afs !~ /\/\.secure\/audit/)) {
#print "sending email on non-gis non-secure to $aemail\n";
system ("echo WARNING  $afs usage is at $newrfsuse\%. SCOM IR for $aci \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
$mes="WARNING\: $afs usage on UNIX $host is at $newrfsuse\%. Please open P4 IR for $aci";
#system ("echo WARNING $afs usage is at $newrfsuse\%. SCOM IR for $aci \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
`/opt/scripts/admin/snmp2scom.ksh "$mes"`;
 }
if ($afs =~ /\/var\/gis/) {
#print "sending email on gis to $aemail\n";
system ("echo WARNING PROD  $afs usage is at $newrfsuse\%. running automatic truncation of audit file \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running auditfile_check\n";
`/aixpacadm/cron/auditfile_check.sh`;
     }
if ($afs =~ /\/\.secure\/audit/) {
#print "sending email on secure audit to $aemail\n";
system ("echo WARNING PROD $afs usage is at $newrfsuse\%. running audittruncate script \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running audittruncate\n";
`/opt/scripts/admin/audittruncate`;
    }
   }
 }
elsif (($rfsuse >=$NPwarn) && ($rfsuse <$NPcrit) && ($host !~ /$prodhost/i) ){
#print "NONPROD WARN\n";
chomp ($afs=$allfilesys);
$allfilesys  =~ s/\//\_/g;
chomp $allfilesys;
#print "bef cmd\n";
$cmd=`ls -l $path/$allfilesys\_\* \|awk \'\{print \$9\}\'`;
#print "cmd $cmd\n";
#print "allfilesys $allfilesys\n";
#print "rfsuse $rfsuse\n";
if ($cmd !~ "$path/$allfilesys\_sm\_$rfsuse\_$DATE") {
`rm $cmd`;
#print "aft cmd\n";
next if ($cmd =~ /$path\/$allfilesys\_sm\_$rfsuse\_$DATE/);
chomp ($newrfsuse=$rfsuse);
#print "AFS NONPROD $afs\n";
#if ($afs !~ /\/var\/gis/) {
if (($afs !~ /\/var\/gis/) || ($afs !~ /\/\.secure\/audit/)) {
#print "sending email on non-gis non-secure to $aemail\n";
system ("echo WARNING  $afs usage is at $newrfsuse\%. \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
   }
if ($afs =~ /\/var\/gis/) {
#print "sending email on gis to $aemail\n";
system ("echo WARNING NONPROD $afs usage is at $newrfsuse\%. running automatic truncation of audit file \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running audifile_check\n";
`/aixpacadm/cron/auditfile_check.sh`;
    }
if ($afs =~ /\/\.secure\/audit/) {
#print "sending email on secure audit to $aemail\n";
system ("echo WARNING NONPROD $afs usage is at $newrfsuse\%. running audittruncate script \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running audittruncate\n";
`/opt/scripts/admin/audittruncate`;
    }
  }
 }
if (($rfsuse >=$Pcrit) && ($host =~ /$prodhost/i)) {
#print "PROD CRIT\n";
chomp ($afs=$allfilesys);
$allfilesys  =~ s/\//\_/g;
chomp $allfilesys;
$cmd=`ls -l $path/$allfilesys\_\* \|awk \'\{print \$9\}\'`;
if ($cmd !~ "$path/$allfilesys\_sm\_$rfsuse\_$DATE") {
`rm $cmd `;
next if ($cmd =~ /$path\/$allfilesys\_sm\_$rfsuse\_$DATE/);
chomp ($newrfsuse=$rfsuse);
#if ($afs !~ /\/var\/gis/) {
if (($afs !~ /\/var\/gis/) || ($afs !~ /\/\.secure\/audit/)) {
#print "sending email on non-gis non-secureto $aemail\n";
system ("echo CRITICAL  $afs usage is at $newrfsuse\%. SCOM IR for $aci \|mailx -s \"$host filesystem CRITICAL\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
$mes="CRITICAL\: $afs usage on UNIX $host is at $newrfsuse\%. Please open P3 IR for $aci";
`/opt/scripts/admin/snmp2scom.ksh "$mes"`;
   }
if ($afs =~ /\/var\/gis/) {
#print "sending email on gis to $aemail\n";
system ("echo CRITICAL PROD $afs usage is at $newrfsuse\%. running automatic truncation of audit file \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running audifile_check\n";
`/aixpacadm/cron/auditfile_check.sh`;
    }
if ($afs =~ /\/\.secure\/audit/) {
#print "sending email on secure audit to $aemail\n";
system ("echo CRITICAL PROD $afs usage is at $newrfsuse\%. running audittruncate script \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running auditturncate\n";
`/opt/scripts/admin/audittruncate`;
     }
   }
 }
elsif (($rfsuse >=$NPcrit) && ($host !~ /$prodhost/i)) {
#print "NONPROD CRIT\n";
chomp ($afs=$allfilesys);
$allfilesys =~ s/\//\_/g ;
chomp $allfilesys;

$cmd=`ls -l $path/$allfilesys\_\* \|awk \'\{print \$9\}\'`;
if ($cmd !~ "$path/$allfilesys\_sm\_$rfsuse\_$DATE") {
`rm $cmd `;
next if ($cmd =~ /$path\/$allfilesys\_sm\_$rfsuse\_$DATE/);
chomp ($newrfsuse=$rfsuse);
if (($afs !~ /\/var\/gis/) || ($afs !~ /\/\.secure\/audit/)) {
#if ($afs !~ /\/var\/gis/) {
#print "sending email on non-gis non-secure  to $aemail\n";
system ("echo CRITICAL NONPROD  $afs usage is at $newrfsuse\%. \|mailx -s \"$host filesystem CRITICAL\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
    }
if ($afs =~ /\/var\/gis/) {
#print "sending email on gis to $aemail\n";
system ("echo CRITICAL NONPROD $afs usage is at $newrfsuse\%. running automatic truncation of audit file \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running audifile_check\n";
`/aixpacadm/cron/auditfile_check.sh`;
     }
if ($afs =~ /\/\.secure\/audit/) {
#print "sending email on secure audit to $aemail\n";
system ("echo CRITICAL NONPROD $afs usage is at $newrfsuse\%. running audittruncate script \|mailx -s \"$host filesystem WARNING\: $afs\" $aemail");
system ("/usr/bin/touch $path/$allfilesys\_sm\_$newrfsuse\_$DATE");
#print "running auditturncate\n";
`/opt/scripts/admin/audittruncate`;
     }
    }
   }
  }
 }

##############################################################################
##############  Resolve if the filesystem issue is fixed  #################### 
##############################################################################
if ($host =~ /$prodhost/i) {
$warn = $Pwarn;
    }
else {
$warn = $NPwarn;
  }
#print "Resolve warn  $warn\n";
if ($os =~/aix/i) {
$rmcmd="ls -l $path/*sm\_\* \|awk \'\{print \$9\}\'";
open (ARMCMD, "$rmcmd|");
while (<ARMCMD>) {
 chomp ($dir=$_);
($pth,$rmfs1) = split (/admin\//, ($dir),2);
#print "rmfs1 $rmfs1\n";
($rmfs,$sm)= split('\_sm', $rmfs1);
$rmfs=~ s/\_/\//g;
chomp ($rmfs);
($sm1,$sm2,$day) = split (/\_/,$sm);
chomp ($sm2);
$rmcmd2="df \-I \|grep  $rmfs\$ \|awk \'\{print \$5\}\'";
$rmcmd3="df \-I \|grep  $rmfs\$ \|awk \'\{print \$6\}\'";
open (ARMCMD2,"$rmcmd2|");
  while (<ARMCMD2>) {
  chomp ($comp1=$_);
$comp1=~s/\%//g;
open (ARMCMD3,"$rmcmd3|");
  while (<ARMCMD3>) {
  chomp ($comp2=$_);
$comp2=~s/\%//g;
if (($rmfs =~/$comp2/) && ($comp1 <$warn)) {
#print "fs $rmfs comp1 $comp1\n";
system ("echo $host filesystem $rmfs issue is RESOLVED. \|mailx -s \"$host Filesystem $rmfs issue is RESOLVED\" $aemail");
`rm $path/$rmfs1`;
    }
   }
  }
 }
}
close ARMCMD;
close ARMCMD2;
close ARMCMD3;

if ($os =~/linux/i) {
$rmcmd="ls -l $path/*sm\_\* \|awk \'\{print \$9\}\'";
open (LRMCMD, "$rmcmd|");
while (<LRMCMD>) {
 chomp ($dir=$_);
($pth,$rmfs1) = split (/admin\//, ($dir),2);
#print "rmfs1 $rmfs1\n";
($rmfs,$sm)= split('\_sm', $rmfs1);
$rmfs=~ s/\_/\//g;
chomp ($rmfs);
($sm1,$sm2,$day) = split (/\_/,$sm);
chomp ($sm2);
$rmcmd2="df \|grep \-w $rmfs\$ \|awk \'\{print \$5\}\'";
$rmcmd3="df \|grep \-w $rmfs\$ \|awk \'\{print \$6\}\'";
open (LRMCMD2,"$rmcmd2|");
  while (<LRMCMD2>) {
  chomp ($comp1=$_);
$comp1=~s/\%//g;
open (LRMCMD3,"$rmcmd3|");
  while (<LRMCMD3>) {
  chomp ($comp2=$_);
$comp2=~s/\%//g;
if (($rmfs =~/$comp2/) && ($comp1 <$warn)) {
#print "fs $rmfs comp1 $comp1\n";
system ("echo $host filesystem $rmfs issue is RESOLVED. \|mailx -s \"$host Filesystem $rmfs issue is RESOLVED\" $aemail");
`rm $path/$rmfs1`;
    }
   }
  }
 }
}
close LRMCMD;
close LRMCMD2;
close LRMCMD3;


##################################################################################################
################################### SWAP Linux ###################################################
$swarn=90;
$scrit=95;

if ( $os =~/linux/i) {
$swapinfo="/usr/bin/free \|grep Swap \|awk '\{print \$2 \" \" \$4\}'";
open (SWAPLX, "$swapinfo|");
    while (<SWAPLX>) {
    chomp ($swapuse=$_);
  ($avail,$free) = split (' ', $swapuse);
  $swapusage=(100-$free/$avail*100);
$SWAPUSE= sprintf("%.0f", $swapusage);
if ( ($SWAPUSE >= $swarn) && ($SWAPUSE < $scrit) ) {
$swapcmd=`ls -l $path/\_$SWAPUSE\_warn\_sm\_$DATE \|awk \'\{print \$9\}\'`;
if ($swapcmd !~ "$path/\_$SWAPUSE\_warn\_sm\_$DATE") {
`rm $swapcmd`;
next if ($swapcmd =~ /$path\/\_$SWAPUSE\_warn\_sm\_$DATE/);
system ("echo WARNING  Swap usage is at $SWAPUSE\% IR for $aci \|mailx -s \"$host swap WARNING\: usage at $SWAPUSE\%\" $aemail");
system ("/usr/bin/touch $path/\_$SWAPUSE\_warn\_sm\_$DATE");
   }
 } 
if (($SWAPUSE >=$scrit) && ($host =~ /$prodhost/i)) {
$swapcmd=`ls -l $path/\_$SWAPUSE\_crit\_sm\_$DATE \|awk \'\{print \$9\}\'`;
if ($swapcmd !~ "$path/\_$SWAPUSE\_crit\_sm\_$DATE") {
`rm $swapcmd`;
next if ($swapcmd =~ /$path\/\_$SWAPUSE\_crit\_sm\_$DATE/);

system ("echo SCOM CRITICAL  Swap usage is at $SWAPUSE\% IR for $aci \|mailx -s \"$host swap CRITICAL\: usage at $SWAPUSE\%\" $aemail ");
system ("/usr/bin/touch $path/\_$SWAPUSE\_crit\_sm\_$DATE");

  $mes = "CRITICAL\: UNIX $host Total Paging space Used\: $SWAPUSE\%. Please open P3 IR for $aci";
`/opt/scripts/admin/snmp2scom.ksh  "$mes"`;
   }
 }
elsif (($SWAPUSE >=$scrit) && ($host !~ /$prodhost/i)) {
$swapcmd=`ls -l $path/\_$SWAPUSE\_crit\_sm\_$DATE \|awk \'\{print \$9\}\'`;
if ($swapcmd !~ "$path/\_$SWAPUSE\_crit\_sm\_$DATE") {
`rm $swapcmd`;

next if ($swapcmd =~ /$path\/\_$SWAPUSE\_crit\_sm\_$DATE/);
system ("echo CRITICAL  Swap usage is at $SWAPUSE\% \|mailx -s \"$host swap CRITICAL\: usage at $SWAPUSE\%\" $aemail ");
system ("/usr/bin/touch $path/\_$SWAPUSE\_crit\_sm\_$DATE");
   }
  }
 }
}
close SWAPLX;

################################### SWAP AIX  ###################################################
if ($os =~/aix/i) {
 open (SWAPAIX, "lsps -s \|grep \-v Total \|awk \'\{print \$2\}\'|");
 while (<SWAPAIX>) {
 chomp($lsps_output=$_);
 ($swused,@sign) = split (/\%/, $lsps_output);

 if (($swused  >=$swarn ) && ($swused <$scrit))  {
$swapcmd=`ls -l $path/\_$swused\_warn\_sm\_$DATE \|awk \'\{print \$9\}\'`;
if ($swapcmd !~ "$path/\_$swused\_warn\_sm\_$DATE") {
`rm $swapcmd`;

next if ($swapcmd =~ /$path\/\_$swused\_warn\_sm\_$DATE/);

system ("echo WARNING  Swap usage is at $swused\% IR for $aci \|mailx -s \"$host swap WARNING\: usage $swused\%\" $aemail ");
system ("/usr/bin/touch $path/\_$swused\_warn\_sm\_$DATE");
 } 
}
if (($swused >=$scrit) && ($host =~ /$prodhost/i)) {
$swapcmd=`ls -l $path/\_$swused\_crit\_sm\_$DATE \|awk \'\{print \$9\}\'`;
if ($swapcmd !~ "$path/\_$swused\_crit\_sm\_$DATE") {
`rm $swapcmd`;

next if ($swapcmd =~ /$path\/\_$swused\_crit\_sm\_$DATE/);

  $mes = "CRITICAL\: UNIX $host Total Paging space Used\: $swused\%.  Please open P3 IR for $aci";
  `/opt/scripts/admin/snmp2scom.ksh "$mes"`;
  system ("echo CRITICAL  Swap usage is at $swused\% IR for $aci \|mailx -s \"$host swap CRITICAL\: usage $swused\%\" $aemail ");
system ("/usr/bin/touch $path/\_$swused\_crit\_sm\_$DATE");
  }
 }
elsif (($swused >=$scrit) && ($host !~ /$prodhost/i)) {
$swapcmd=`ls -l $path/\_$swused\_crit\_sm\_$DATE \|awk \'\{print \$9\}\'`;
if ($swapcmd !~ "$path/\_$swused\_crit\_sm\_$DATE") {
`rm $swapcmd`;

next if ($swapcmd =~ /$path\/\_$swused\_crit\_sm\_$DATE/);

  system ("echo CRITICAL  Swap usage is at $swused\% \|mailx -s \"$host swap CRITICAL\: usage at $swused\%\" $aemail ");
system ("/usr/bin/touch $path/\_$swused\_crit\_sm\_$DATE");
     }
    }
   }
  }
close SWAPAIX;
system ("rm $ADMIN $NADMIN $NONROOTFS $EXCLFS $ROOTFS $path/rootfs.out $NONROOTFS.s $ROOTFS.s");

`sleep 120`; 
chomp ($NEWTIME=`date +%H%M`);
if ($NEWTIME >2330){
`rm $path/_*sm_*`
}
exit;
