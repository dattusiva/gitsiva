#!/bin/bash
# author: Maqsood Ahmed
# updates:
#	Jerry Silverstein 9/2019 (see #### comments)
#
#
# Functions go here
######### Updates
## 5/21/20 - JRN - corrected nodev/nosuid checks to ignore any commented filesystems
## 12/2/20 - JRN - Changed aide.db check to look for Suse or Red Hat db file instead
##                 of a wildcard.  The wildcard method was getting errors if a dbinit
##                 process was running while this script ran (there is a .bak file)
## 12/8/20 - JRN - Updated nosuid checking for /usr/sap and /hana/shared filesystems.
##                 Added check for to determine if exception end date has passed.
## 2/2/21  - JRN - Changed SAP exception to Feb 27, 2021
## 3/9/21  - JRN - Changed SAP exception to Feb 27, 2022
## 12/7/21 - JRN - Correcting spelling of "please"
## 2/10/22 - JRN - Changed what the script looks for in root's crontab to determine
##                 if aide is scheduled.  Since there are multiple "aide" entries,
##                 changed to look for "aidecheck"
## 05/20/2022 -    Chuck Richmond - updating for debian and coreos aligned distros for cloud native
##                 deployments.

#-------------------------------------- --------------------------------------
## helper functions
DISTRO() {
   distrolike="$(cat /etc/os-release | awk -F= '/ID_LIKE=/ { print $2 }')"
   os_id="$(cat /etc/os-release | awk -F= '/^ID=/ { print $2 }')"
   echo ${os_id}
   # echo ${distrolike}
}

## Section 4.1
USR() {
   printf "\n\nBeginning of user account security -------------------\n"

   tmp1=$(DISTRO)
   ## Only one1 uid=0  root
   grep ":0:" /etc/passwd | grep -v ^root >/tmp/664lx_tmp
   TMP3=''
   while read USER; do
      TMP1=$(echo ${USER} | awk -F: '{print $3}')
      if [ ${TMP1} -eq 0 ]; then
         TMP3="$TMP3 ${USER}"
      fi
   done </tmp/664lx_tmp
   rm -f /tmp/664lx_tmp
   if [ -z "${TMP3}" ]; then
      echo "Audit of Only 1 uid=0 root passed "
      RT=$(expr ${RT} + 1)
   else
      echo "Audit of Only 1 uid=0 root FAILED with value of:"
      echo "${TMP3}"
   fi
   GT=$(expr ${GT} + 1)

   ##  echo "Unneeded userid valid shells"
   CT=0
   USERS=" bin uucp daemon lp"
   for USRS in ${USERS}; do
      TEST=$(grep ^${USRS}: /etc/passwd | awk -F: '{print $7}')
      ## if the user has a shell, verify it is correct
      if [ -n "${TEST}" ]; then
         if [ "${TEST}" != "/bin/false" ] && [ "${TEST}" != "/sbin/nologin" ]; then
            CT=$(expr ${CT} + 1)
         fi
      else
         ## else if the shell is empty and user exists, it's a bad user
         TEST=$(grep ^${USRS}: /etc/passwd)
         if [ -n "${TEST}" ]; then
            CT=$(expr ${CT} + 1)
         fi
      fi
   done

   if [ ${CT} -eq 0 ]; then
      echo "Audit of valid shell in un-needed ids passed"
      RT=$(expr ${RT} + 1)
   else
      echo "Audit of valid shell in un-needed ids FAILED for ${CT} of the IDs"
   fi
   echo "IDs checked: ${USERS}"
   GT=$(expr ${GT} + 1)

   ## existence of .bash_history or .sh_history for root
   if [ -f ~root/.bash_history ] || [ -f ~root/.sh_history ]; then
      echo "Audit .bash_history or .sh_history for root passed "
      RT=$(expr ${RT} + 1)
   else
      echo "Audit .bash_history or .sh_history for root FAILED "
   fi
   GT=$(expr ${GT} + 1)

   ## No . in root's path
   ## Check in /etc/profile path
   #### put : around . to fix problem where TMP is empty but still gets FAILED message
   TMP=$(grep "PATH=" /etc/profile | grep ":\.:")
   if [ -z "${TMP}" ]; then
      echo "Audit of NO . in /etc/profile's path passed "
      RT=$(expr ${RT} + 1)
   else
      echo "Audit of NO . in /etc/profile's path FAILED with value of:"
      echo "${TMP}"
   fi
   GT=$(expr ${GT} + 1)

   ## Check in /root/.bash_profile path
   TMP=$(grep "PATH=" /root/.bash_profile | grep "\.")
   if [ -z "${TMP}" ]; then
      echo "Audit of NO . in root's .profile passed "
      RT=$(expr ${RT} + 1)
   else
      echo "Audit of NO . in root's .profile FAILED with value of:"
      echo "${TMP}"
   fi
   GT=$(expr ${GT} + 1)

   ## Verify home directory of root is /root
   TMP=$(grep "^root:" /etc/passwd | awk -F: '{print $6}')
   if [ "${TMP}" = "/root" ]; then
      echo "Audit of root home directory set to /root passed "
      RT=$(expr ${RT} + 1)
   else
      echo "Audit of root home directory set to /root FAILED with value of:"
      echo "${TMP}"
   fi
   GT=$(expr ${GT} + 1)

   ## Verify home directory permissions for root
   PERM="drwxr-x---"
   PERM1="drwx------"
   ####    PERM2=`ls -ld /root |awk '{print $1}'`
   #### new 11th permission bit needs cut to keep to 10 bits for current comparisons
   PERM2=$(ls -ld /root | cut -c 1-10)
   if [ "${PERM2}" = "${PERM}" ] || [ "${PERM2}" = "${PERM1}" ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of root's home directory passed with result of ${PERM2}"
   else
      echo "Audit of root's home directory FAILED with result of ${PERM2}"
   fi
   GT=$(expr ${GT} + 1)
}

## Section 4.2
PAS_SEC() {
   printf "\n\nBeginning of password security function --------------\n"

   ## Check 90 day password expiration
   TMP=90
   TMP1=$(grep PASS_MAX_DAYS /etc/login.defs | grep -v ^# | awk '{print $2}')
   if [ ${TMP1} -le ${TMP} ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of password max age passed with result of ${TMP1}"
   else
      echo "Audit of password max age FAILED with result of ${TMP1}"
   fi
   GT=$(expr ${GT} + 1)

   ## Check minimum password length
   ## The default length in system-auth, if not specified, is 10
   TMP=10
   TMP1=$(grep pam_cracklib /etc/pam.d/common-password-pc | awk -F"minlen=" '{print $2'} | awk '{print $1}')
   if [ -z ${TMP1} ] || [ ${TMP1} -ge ${TMP} ]; then
      RT=$(expr ${RT} + 1)
      if [ -z ${TMP1} ]; then
         echo "Audit of password min length passed with result of 'default'"
      else
         echo "Audit of password min length passed with result of ${TMP1}"
      fi
   else
      echo "Audit of password min length FAILED with result of ${TMP1}"
   fi
   GT=$(expr ${GT} + 1)

   ## Verify /etc/shadow file exists
   if [ -f /etc/shadow ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of /etc/shadow passed "
   else
      echo "Audit of /etc/shadow FAILED "
   fi
   GT=$(expr ${GT} + 1)
}

## Section 4.3
FILE_SEC() {
   printf "\n\nBeginning of file and directory security -------------\n"

   set -x
   ## Check system umask

   G1="027"
   G2="077"

   if [ -f /etc/login.defs ]; then
      GX=$(grep -i ^umask /etc/login.defs | awk '{print $2}')
   else
      GX=$(grep -i ^umask /etc/profile | awk '{print $2}')
   fi

   if [ "$GX" == "$G1" ] || [ "$GX" == "$G2" ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of umask passed with a value of ${GX} "
   else
      echo "Audit of umask FAILED with a value of ${GX}"
   fi

   GT=$(expr ${GT} + 1)

   ## Check nosuid and nodev settings on filesystems
   FS=$(egrep 'ext|xfs|btrfs' /etc/fstab | egrep -v ' / |	/	| /boot |	/boot	| /bin |	/bin	| /usr |	/usr	| /var |	/var	| /opt |	/opt	| /dev |	dev	| /sbin |	/sbin	|/grub2/| /.snapshots |subvol=|^#' | awk '{print $2}')
   for FS1 in ${FS}; do
      egrep " ${FS1} |	${FS1}	" /etc/fstab | grep -v "^#" | grep nosuid
      RTCND1=$?
      egrep " ${FS1} |	${FS1}	" /etc/fstab | grep -v "^#" | grep nodev
      RTCND2=$?
      if [ ${RTCND1} -eq 0 ] && [ ${RTCND2} -eq 0 ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of nosuid and nodev passed"
      else
         #### list of filesystems allowed missing nosuid option
         cur_epoch=$(date +%s)
         if [ ${RTCND1} -ne 0 ] && ([ "${FS1}" = "/hana/shared" ] || [ "${FS1}" = "/usr/sap" ] || [ "${FS1}" = "/var/lib/awx" ] || [ "${FS1}" = "/var/lib/pgsql" ]); then
            exemption_nosuid=$(grep $host $exemption_list | grep nosuid)
            if [ -z "$exemption_nosuid" ]; then
               echo "Audit of nosuid and nodev FAILED for filesystem ${FS1}"
            else
               exception_num=$(echo $exemption_nosuid | awk -F: '{print $3}')
               exception_date=$(echo $exemption_nosuid | awk -F: '{print $4}')
               if [ $cur_epoch -lt $exception_date ]; then
                  RT=$(expr ${RT} + 1)
                  echo "Audit of nodev passed for filesystem ${FS1} (See exception $exception_num)"
               else
                  echo "Audit of nosuid and nodev FAILED for filesystem ${FS1} due to old exception $exception_num"
               fi
            fi
         else
            echo "Audit of nosuid and nodev FAILED for filesystem ${FS1}"
         fi

      fi
      GT=$(expr ${GT} + 1)
   done

   ## Check permissions on /dev/mem and /dev/kmem
   # Permissions have to be equal to or more restrictive then "crw-r-----"
   USER="root"
   GROUP="kmem"
   for FILES in /dev/mem /dev/kmem; do
      if [ -f ${FILES} ]; then
         FILE1=$(find ${FILES} -perm /u+x,g+wx,o+rwx)
         USER1=$(ls -l ${FILES} | awk '{print $3}')
         GROUP1=$(ls -l ${FILES} | awk '{print $4}')
         if [ -z "${FILE1}" ] && [ "${USER1}" = "${USER}" ] && [ "${GROUP1}" = "${GROUP}" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of ${FILES} passed"
         else
            ####             PERM1=`ls -l ${FILES} |awk '{print $1}'`
            #### new 11th permission bit needs cut to keep 10bit comparisons.
            PERM1=$(ls -l ${FILES} | cut -c 1-10)
            echo "Audit of ${FILES} FAILED with perm=${PERM1} user=${USER1} group=${GROUP1}"
         fi
         GT=$(expr ${GT} + 1)
      fi
   done

   ## Check system log files in /var/log
   # Permissions have to be equal to or more restrictive then "-rw-r--r--"
   USER="root"
   for FILES in cron dmesg messages rpmpkgs secure wtmp; do
      if [ -f /var/log/${FILES} ]; then
         #FILE1=`find /var/log -name ${FILES} -perm /u+x,g+wx,o+wx`
         FILE1=$(find /var/log -name ${FILES} -perm /u+x,g+x,o+wx)
         USER1=$(ls -l /var/log/${FILES} | awk '{print $3}')
         if [ -z "${FILE1}" ] && [ "${USER1}" = "${USER}" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of /var/log/${FILES} passed"
         else
            ####             PERM1=`ls -l /var/log/${FILES} |awk '{print $1}'`
            #### new 11th permission bit needs cut for 10bit comparisions
            PERM1=$(ls -l /var/log/${FILES} | cut -c 1-10)
            #### check wtmp separately since it must have 664 permissions instead of 640
            if [${FILES} = "wtmp"] && [PERM1 = "rw-rw-r"]; then
               RT=$(expr ${RT} +1)
               echo "Audit of /var/log/${FILES} passed"
            else
               echo "Audit of /var/log/${FILES} FAILED with perm=${PERM1} user=${USER1}"
            fi
         fi
         GT=$(expr ${GT} + 1)
      fi
   done

   ## Check permissions on /var/log/btmp
   # Permissions have to be equal to or more restrictive then "-rw-rw----"
   USER="root"
   GROUP="root"

   if [ -f /var/log/btmp ]; then
      FILE1=$(find /var/log/btmp -perm /u+x,g+x,o+rwx)
      # check if the file has no group access
      FILE2=$(find /var/log/btmp -perm /u+x,g+rwx,o+rwx)
      USER1=$(ls -l /var/log/btmp | awk '{print $3}')
      GROUP1=$(ls -l /var/log/btmp | awk '{print $4}')
      GRPPERM1=$(ls -l /var/log/btmp | awk '{print $4}')
      if [ -z "${FILE1}" ] && [ "${USER1}" = "${USER}" ]; then
         # no group access then no reason to look at group assignment
         if [ -z "${FILE2}" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of /var/log/btmp passed"
         else
            if [ "${GROUP1}" == "${GROUP}" ]; then
               RT=$(expr ${RT} + 1)
               echo "Audit of /var/log/btmp passed"
            else
               ####          		PERM1=`ls -l /var/log/btmp |awk '{print $1}'`
               #### new 11th permission bit needs cut to keep 10bit comparisons
               PERM1=$(ls -l /var/log/btmp | cut -c 1-10)
               echo "Audit of /var/log/btmp FAILED with perm=${PERM1} user=${USER1} group=${GROUP1}"
            fi
         fi
      else
         ####          PERM1=`ls -l /var/log/btmp |awk '{print $1}'`
         #### new 11th permission bit needs cut to keep 10bit comparisons
         PERM1=$(ls -l /var/log/btmp | cut -c 1-10)
         echo "Audit of /var/log/btmp FAILED with perm=${PERM1} user=${USER1} group=${GROUP1}"
      fi
      GT=$(expr ${GT} + 1)
   fi

   ## Check permissions on /etc/passwd and /etc/group
   # Permissions have to be equal to or more restrictive then "-rw-r--r--"
   USER="root"
   GROUP="root"
   for FILES in /etc/passwd /etc/group; do
      if [ -f ${FILES} ]; then
         FILE1=$(find ${FILES} -perm /u+x,g+wx,o+wx)
         USER1=$(ls -l ${FILES} | awk '{print $3}')
         GROUP1=$(ls -l ${FILES} | awk '{print $4}')
         if [ -z "${FILE1}" ] && [ "${USER1}" = "${USER}" ] && [ "${GROUP1}" = "${GROUP}" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of ${FILES} passed"
         else
            ####             PERM1=`ls -l ${FILES} |awk '{print $1}'`
            #### new 11th permission bit needs cut to keep 10bit comparisons
            PERM1=$(ls -l ${FILES} | cut -c 1-10)
            echo "Audit of ${FILES} FAILED with perm=${PERM1} user=${USER1} group=${GROUP1}"
         fi
         GT=$(expr ${GT} + 1)
      fi
   done

   ## Check permissions on /etc/shadow
   # Permissions have to be equal to or more restrictive then "-rw-------"
   #####  Red Hat does not have group shadow so use root instead, Suse will use shadow group
   USER="root"
   GROUP="root"
   #  OS=`ls -ld /etc/redhat-release`
   if [ -z ${os_id} ] || [ "${os_id}" = "suse"]; then
      GROUP="shadow"
   fi
   if [ -f /etc/shadow ]; then
      FILE1=$(find /etc/shadow -perm /u+x,g+rwx,o+rwx)
      USER1=$(ls -l /etc/shadow | awk '{print $3}')
      GROUP1=$(ls -l /etc/shadow | awk '{print $4}')
      if [ -z "${FILE1}" ] && [ "${USER1}" = "${USER}" ] && [ "${GROUP1}" = "${GROUP}" ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of /etc/shadow passed"
      else
         ####          PERM1=`ls -l /etc/shadow |awk '{print $1}'`
         #### new 11th permission bit needs cut for current 10bit comparisons
         PERM1=$(ls -l /etc/shadow | cut -c 1-10)
         echo "Audit of /etc/shadow FAILED with perm=${PERM1} user=${USER1} group=${GROUP1}"
      fi
      GT=$(expr ${GT} + 1)
   fi


   ## Check permissions on /tmp /var/tmp
   PERM="drwxrwxrwt"
   for DIRS in /tmp /var/tmp; do
      ####       PERM1=`ls -ld ${DIRS} |awk '{print $1}'`
      #### new 11th permission bit needs cut for current 10bit comparisions
      PERM1=$(ls -ld ${DIRS} | cut -c 1-10)
      if [ "${PERM1}" = "${PERM}" ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of ${DIRS} passed"
      else
         echo "Audit of ${DIRS} FAILED with perm=${PERM1}"
      fi
      GT=$(expr ${GT} + 1)
   done

   ## Check permissions on startup files in $HOME directories
   # Permissions have to be equal to or more restrictive then "-rwxr-----"
   for USER in $(cat /etc/passwd | awk -F: '{print $1}'); do
      if [ "$USER" != "operator" ]; then
         HOMEDIR=$(grep ^${USER}: /etc/passwd | awk -F: '{print $6}')
         for FILES in .profile .bashrc .login .tcshrc; do
            if [ -f ${HOMEDIR}/${FILES} ]; then
               FILE1=$(find ${HOMEDIR}/${FILES} -perm /g+wx,o+rwx)
               USER1=$(ls -l ${HOMEDIR}/${FILES} | awk '{print $3}')
               if [ -z "${FILE1}" ] && [ "${USER1}" = "${USER}" ]; then
                  RT=$(expr ${RT} + 1)
                  echo "Audit of ${HOMEDIR}/${FILES} passed"
               else
                  ####                PERM1=`ls -l ${HOMEDIR}/${FILES} |awk '{print $1}'`
                  #### new 11th permission bit needs cut for current 10bit comparisions
                  PERM1=$(ls -l ${HOMEDIR}/${FILES} | cut -c 1-10)
                  echo "Audit of ID ${USER} ${HOMEDIR}/${FILES} FAILED with perm=${PERM1} user=${USER1}"
               fi
               GT=$(expr ${GT} + 1)
            fi
         done
      fi
   done

   ## Check for .rhosts and .netrc
   # Files shouldn't exist but if they do they have to be owned by root and empty
   # Permissions have to be equal to or more restrictive then "-rw-------"
   for USER in $(cat /etc/passwd | awk -F: '{print $1}'); do
      HOMEDIR=$(grep ^${USER}: /etc/passwd | awk -F: '{print $6}')
      for FILES in .rhosts .netrc; do
         if [ -f ${HOMEDIR}/${FILES} ]; then
            FILE1=$(find ${HOMEDIR}/${FILES} -perm /o+x,g+rwx,o+rwx)
            USER1=$(ls -l ${HOMEDIR}/${FILES} | awk '{print $3}')
            ENTRIES=$(cat ${HOMEDIR}/${FILES} | egrep -v '^#|^$' | wc -l)
            if [ -z "${FILE1}" ] && [ "${USER1}" = "root" ] && [ "$ENTRIES" = 0 ]; then
               RT=$(expr ${RT} + 1)
               echo "Audit of ${HOMEDIR}/${FILES} passed"
            else
               ####                PERM1=`ls -l ${HOMEDIR}/${FILES} |awk '{print $1}'`
               #### new 11th permission bit needs cut for current 10bit comparisons
               PERM1=$(ls -l ${HOMEDIR}/${FILES} | cut -c 1-10)
               echo "Audit of ${HOMEDIR}/${FILES} FAILED with perm=${PERM1} user=${USER1}"
            fi
            GT=$(expr ${GT} + 1)
         fi
      done
   done

   ## Verify only NFS version 4 is being used
   GX=$(grep -v vers\=4 /etc/exports 2>/dev/null)
   if [ -z "$GX" ]; then
      echo "Audit of /etc/exports file passed"
      RT=$(expr ${RT} + 1)
   else
      #### Hana servers need /etc/exports for Rubrik backups
      arch=$(uname -i)
      if [ ${arch} = "ppc64le" ]; then
         echo "HANA servers must have /etc/exports for Rubrik - passed"
         RT=$(expr ${RT} + 1)
      else
         #### Check list of servers allowed /etc/exports
         cur_epoch=$(date +%s)
         exemption_nfs=$(grep $host $exemption_list | grep nfs | grep -v ^#)
         if [ -z "$exemption_nfs" ]; then
            echo "Audit of /etc/exports FAILED.  File exists "
         else
            exception_num=$(echo $exemption_nfs | awk -F: '{print $3}')
            exception_date=$(echo $exemption_nfs | awk -F: '{print $4}')
            if [ $cur_epoch -lt $exception_date ]; then
               RT=$(expr ${RT} + 1)
               echo "Audit of /etc/exports passed (See exception $exception_num)"
            else
               echo "Audit /etc/exports FAILED due to old exception $exception_num"
            fi
         fi
      fi
   fi
   GT=$(expr ${GT} + 1)
}
## Section 4.4
SYS_SEC() {
   printf "\n\nBeginning of system security -------------------------\n"

   ## Check if NetIQ is installed
   if [ -f /usr/vsaunix/netiq/vsau/bin/detectd ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of NetIQ passed"
   else
      #### Check if Aide is installed
      if [ -f /var/lib/aide/aide.db ] || [ -f /var/lib/aide/aide.db.gz ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of AIDE installed passed"
      else
         echo "No Intrusion Detection (NetIQ nor AIDE) Found so FAILED"
      fi
   fi
   GT=$(expr ${GT} + 1)

   #### Check if AIDE run is scheduled
   if [ -f /var/lib/aide/aide.db ] || [ -f /var/lib/aide/aide.db.gz ]; then
      if [ "${os_id}" = '"amzn"' ] || [ "${os_id}" = "ubuntu" ]; then
         FILE1=$(cat /etc/cron.daily/* | grep aidecheck | awk '{print $2}')
         if [ -n "${FILE1}" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of AIDE schedule run passed (amzn, ubuntu)"
         else
            echo "Audit of AIDE schedule run FAILED (amzn, ubuntu)"
         fi
      else
         SCHEDa=$(crontab -l | grep -v ^# | grep aidecheck | awk '{print $5}')
         if [ -n "${SCHEDa}" ] && [ "${SCHEDa}" = "*" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of AIDE schedule run passed"
         else
            echo "Audit of AIDE schedule run FAILED"
         fi
      fi
      GT=$(expr ${GT} + 1)
   fi

   ## Check if McAfee is installed
   SCAN=$(find / -name uvscan -a -D -type f)
   if [ -z ${SCAN} ]; then
      #### Check that ClamAV is installed for pcc64le
      #### ClamAV for other linux uses clamd.d for configuration CR
      CLAM=$(ls /etc/clamd.conf /etc/clamd.d/)
      if [ -z ${CLAM} ]; then
         echo "No Antivirus (McAfee nor CLamAV) Found so FAILED"
      else
         RT=$(expr ${RT} + 1)
         echo "Audit of ClamAV installed passed"
      fi
   else
      RT=$(expr ${RT} + 1)
      echo "Audit of McAfee installed passed"
   fi
   GT=$(expr ${GT} + 1)

   ## Check if McAfee is scheduled daily
   SCHED=$(crontab -l | grep -v ^# | grep mcafee_fullscan | awk '{print $5}')
   if [ -n "${SCHED}" ] && [ "${SCHED}" = "*" ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of McAfee scheduled daily passed"
   else
      #### Check for clamAV
      if [ "${os_id}" = '"amzn"' ] || [ "${os_id}" = "ubuntu" ]; then
         FILE1=$(cat /etc/cron.daily/* | grep clamscan | awk '{print $2}')
         if [ -n "${FILE1}" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of ClamAV scheduled daily passed (amzn, ubuntu)"
         else
            echo "No Antivirus (McAfee nor ClamAV) scheduled daily so FAILED (amzn, ubuntu)"
         fi
      else
         SCHED2=$(crontab -l | grep -v ^# | grep clamav | awk '{print $5}')
         if [ -n "${SCHED2}" ] && [ "${SCHED2}" = "*" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of ClamAV scheduled daily passed"
         else
            echo "No Antivirus (McAfee nor ClamAV) scheduled daily so FAILED"
         fi
      fi
   fi
   GT=$(expr ${GT} + 1)

   ## Check for console only access for root
   TMP=$(grep PermitRootLogin /etc/ssh/sshd_config | grep -v ^# | awk '{print $2}')
   if [ -n "${TMP}" ]; then
      if [ "${TMP}" = "no" ] || [ "${TMP}" = "without-password" ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of console only root access passed"
      else
         echo "Audit of console only root access FAILED"
      fi
   elif [ $(cat /etc/securetty | grep -v ^# | wc -l) -eq 1 ] && [ $(cat /etc/securetty | grep -v ^# | head -1) = "console" ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of console only root access passed"
   else
      echo "Audit of console only root access FAILED"
   fi
   GT=$(expr ${GT} + 1)

   ## Check permissions of "crontab" directories and files
   ##### RedHat does not have tabs directory so don't check it.
   #  OS=`ls -ld /etc/redhat-release`
   #  if [ -z ${OS} ]
   if [ -z ${os_id} ]; then
      PERM="---"
      PERM1=$(ls -ld /var/spool/cron/tabs | cut -c 8-10)
      if [ "${PERM1}" = "${PERM}" ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of /var/spool/cron/tabs passed"
      else
         echo "Audit of /var/spool/cron/tabs FAILED with perm=${PERM1}"
      fi
      GT=$(expr ${GT} + 1)

      PERM="-rw-------"
      for FILES in $(ls -1 /var/spool/cron/tabs); do
         ####	       PERM1=`ls -l /var/spool/cron/tabs/${FILES} |awk '{print $1}'`
         #### new 11th permission bit needs cut for current 10bit comparisons
         PERM1=$(ls -l /var/spool/cron/tabs/${FILES} | cut -c 1-10)
         if [ "${PERM1}" = "${PERM}" ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of /var/spool/cron/tabs/${FILES} passed"
         else
            echo "Audit of /var/spool/cron/tabs/${FILES} FAILED with perm=${PERM1}"
         fi
         GT=$(expr ${GT} + 1)
      done
   fi

   PERM="---"
   PERM1=$(ls -ld /etc/cron.d | cut -c 8-10)
   if [ "${PERM1}" = "${PERM}" ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of /etc/cron.d passed"
   else
      echo "Audit of /etc/cron.d FAILED with perm=${PERM1}"
   fi
   GT=$(expr ${GT} + 1)

   for FILES in $(ls /etc/cron.d); do
      #### look for links to other files (so far only on HANA ppc64)
      PERM0=$(ls -l /etc/cron.d/${FILES} | cut -c 1-10)
      PERM1=$(ls -l /etc/cron.d/${FILES} | cut -c 8-10)
      LINK="0"
      if [ "${PERM0}" = "lrwxrwxrwx" ]; then
         #### if found a link, check the actual file
         FILE1=$(ls -l /etc/cron.d/${FILES} | awk '{print $11}')
         PERM1=$(ls -l ${FILE1} | cut -c 8-10)
         LINK="1"b
      fi
      if [ "${PERM1}" = "${PERM}" ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of /etc/cron.d/${FILES} passed"
      else
         if [ ${LINK} = "1" ]; then
            ####		 	PERM2=`ls -l ${FILE1} | awk '{print $1}'`
            #### new 11th permission bit needs cut for current 10bit comparisons
            PERM2=$(ls -l ${FILE1} | cut -c 1-10)
         else
            ####          		PERM2=`ls -l /etc/cron.d/${FILES} | awk '{print $1}'`
            #### new 11th permission bit needs cut for current 10bit comparisons
            PERM2=$(ls -l /etc/cron.d/${FILES} | cut -c 1-10)
         fi
         echo "Audit of /etc/cron.d/${FILES} FAILED with perm=${PERM2}"
      fi
      GT=$(expr ${GT} + 1)
   done

   ## Authorized banner on /etc/motd
   TMP=$(grep http /etc/motd | cut -d"/" -f5)
   if [ -z "${TMP}" ]; then
      echo "Audit of Authorized banner /etc/motd FAILED."
   else
      echo "Audit of Authorized banner /etc/motd passed"
      RT=$(expr ${RT} + 1)
   fi
   GT=$(expr ${GT} + 1)

   ## Check if NTP is running
   #/sbin/service ntpd status |grep "running" > /dev/null
   ps -ef | grep -v grep | grep "ntpd" >/dev/null
   if [ $? -eq 0 ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of NTP passed"
   else
      #### Newer linux servers use chronyd as default to replace ntpd
      ps -ef | grep -v grep | grep "chronyd" >/dev/null
      if [ $? -eq 0 ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of chronyd passed"
      else
         echo "Audit of NTP or chronyd FAILED"
      fi
   fi
   GT=$(expr ${GT} + 1)

   ## Check TMOUT variable for root
   TMP=$(su - root -c "env |grep TMOUT" | awk -F= '{print $2}')
   if [ -n "${TMP}" ] && [ ${TMP} -le 3600 ]; then
      RT=$(expr ${RT} + 1)
      echo "Audit of TMOUT for root passed"
   else
      echo "Audit of TMOUT for root FAILED"
   fi
   GT=$(expr ${GT} + 1)

   ## Check if a modem is being used.
   if [ -f /etc/dialups ]; then
      echo "Audit of modems FAILED, /etc/dialups exists"
   else
      echo "Audit of modems passed, /etc/dialups does not exist"
      RT=$(expr ${RT} + 1)
   fi
   GT=$(expr ${GT} + 1)

   if [ -f /etc/d_passwd ]; then
      echo "Audit of modems FAILED, /etc/d_passwd exists"
   else
      echo "Audit of modems passed, /etc/d_passwd does not exist"
      RT=$(expr ${RT} + 1)
   fi
   GT=$(expr ${GT} + 1)
}

## Section 4.5
NET_SEC() {
   printf "\n\nBeginning of network security ------------------------\n"

   ## Check if openssh is installed
   for PACKS in openssh openssh-clients openssh-server; do
      TMP=$(rpm -q ${PACKS})
      if [ -n "${TMP}" ]; then
         RT=$(expr ${RT} + 1)
         echo "Audit of ${PACKS} passed"
      else
         echo "Audit of ${PACKS} FAILED"
      fi
      GT=$(expr ${GT} + 1)
      TMP=''
   done

   ## Check for remote login services
   for SYS in login shell telnetd ftpd uucp tftp smtp finger daytime chargen time echo discard; do
      for FILES in $(ls /etc/xinetd.d | grep $SYS); do
         grep disable /etc/xinetd.d/$FILES | grep yes >/dev/null
         if [ $? -eq 0 ]; then
            RT=$(expr ${RT} + 1)
            echo "Audit of ${SYS} passed"
         else
            echo "Audit of ${SYS} FAILED"
         fi
         GT=$(expr ${GT} + 1)
      done
   done

   ## Check for /etc/hosts.equiv
   if [ -f /etc/hosts.equiv ]; then
      FILE1=$(find /etc/hosts.equiv -perm /u+x,g+wx,o+wx)
      if [ $(cat /etc/hosts.equiv | egrep -v '^#|^$' | wc -l) -ne 0 ] || [ ! -z "${FILE1}" ]; then
         echo "Audit of /etc/hosts.equiv FAILED"
      else
         echo "Audit of /etc/hosts.equiv passed"
         RT=$(expr ${RT} + 1)
      fi
   else
      echo "Audit of /etc/hosts.equiv passed"
      RT=$(expr ${RT} + 1)
   fi
   GT=$(expr ${GT} + 1)
}

#----------------------------------------------------------------------------
# Main Line code here
#----------------------------------------------------------------------------
exemption_list=/opt/scripts/admin/664_exemption.list
test=$(echo "$0" | cut -c1)
if [ "$test" = "." ]; then
   actual=$(echo $0 | cut -c2-)
   total=${PWD}$actual
else
   total=$0
fi

host=$(hostname)
GT=0
RT=0
DT=$(date "+Date: %m/%d/%y")
os_id=$(DISTRO)
for count in 1; do
   echo "STANDARD #664lx:  LINUX SECURITY STANDARD NON-CONFIDENTIAL DATA  $DT"
   echo "$host    From script: $total                              os: $os_id"
   echo "*******************************************************************"

   USR
   PAS_SEC
   FILE_SEC
   SYS_SEC
   NET_SEC
   echo "_______________________________________________________"
done >/tmp/$host-LINUX-664lx.report 2>/tmp/$host-LINUX-664lx.err

echo "Scored ${RT} out a Grand Total of: ${GT} " >>/tmp/$host-LINUX-664lx.report
if [ ${RT} -lt ${GT} ]; then
   /opt/scripts/admin/snmp2scom.ksh "Security Configuration Notification - HOST: $host has scored:  ${RT} out a Grand Total of: ${GT}. Please Review report."
   echo "send report to SCOM"
fi
