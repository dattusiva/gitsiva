#!/usr/bin/sh

######################################################
# Get ITD  Linux patching reports
# Maqsood Ahmed
# 03/14/2022
#
####################################################

div=itd

PTH=/opt/scripts/admin/lxpatch/${div}
SLIST=/opt/scripts/admin/alllinuxservers.dat
#SLIST=$PTH/servers.txt
#DATE=`date +%Y%m%d`
DATE=`date +%Y%m`
OUTPUT=$PTH/${div}_linux_patch_report_${DATE}
TIMEOUT="ConnectTimeout=40"
NOPWD="PasswordAuthentication=no"

rhel=$PTH/${div}_rhel_srvrs
suse=$PTH/${div}_suse_srvrs
expnd=$PTH/${div}_expndsuprt_srvrs

>$expnd
>$suse
>$rhel

cd $PTH
echo "Server Name,OS,Online,Status,Patches Outstanding" > $OUTPUT
   for server in `cat $SLIST`
     do
ping -c 2 $server >/dev/nul
    if [ $? -eq 0 ] ;  then
    stat="up"
 echo "$server is up"

ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no  $server hostnamectl | grep "Operating System: SLES Expanded" >/dev/null
 if [ $? -eq 0 ] ; then
echo $server >>$expnd
 fi
ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $server hostnamectl | grep "Operating System: SUSE Linux" >/dev/null
 if [ $? -eq 0 ] ; then
echo $server >>$suse
 fi
ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $server hostnamectl | egrep "Operating System: RHEL|Operating System: Red Hat" >/dev/null
 if [ $? -eq 0 ] ; then
echo $server >>$rhel
 fi
else 
stat="down"
echo "$server is down"
echo "$server,,$stat,,0" >> $OUTPUT
   fi
done
sleep 5
echo "running rest of the script"

##############################  SUSE Linux   ##################################
echo "getting suse servers info"
 for suse_srvrs in `cat $suse`
  do
echo $suse_srvrs
sub=`ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $suse_srvrs zypper lr`
  if [ $? -eq 0 ] ; then
   sub="Registered"
  else 
   sub="Not Registered"
  fi
patches=`ssh -o $TIMEOUT -o $NOPWD  -o StrictHostKeyChecking=no $suse_srvrs zypper lp |grep "Found "[1-9][0-9]*" applicable patch" |awk '{print $2}'`
  if [ $patches > 0 ] ; then
   ptchdue=$patches
   else
   ptchdue=0
  fi
echo "$suse_srvrs $sub $ptchdue"
if [[ $sub == "Not Registered" ]] ; then
   ptchdue=1
  fi
echo "$suse_srvrs,SUSE,$stat,$sub,$ptchdue" >> $OUTPUT
  done

##################  Expanded Support ############################
echo "getting expanded_support servers info"
  for expnd_srvrs in `cat $expnd`
  do
echo "$expnd_srvrs"

sub=`ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $expnd_srvrs yum repolist |grep susemanager`
  if [ $? -eq 0 ] ; then
   sub="Registered"
  else 
   sub="Not Registered"
  fi
patches=`ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $expnd_srvrs yum updateinfo list |grep "^CL" |awk '{print $1}' |sort |uniq |wc -l` 
  if [ $? -eq 0 ] ; then
   ptchdue=$patches
   else
   ptchdue=0
   fi
echo "$expnd_srvrs $sub $ptchdue"
if [[ $sub == "Not Registered" ]] ; then
   ptchdue=1
  fi
echo "$expnd_srvrs,RHEL_Expanded,$stat,$sub,$ptchdue" >> $OUTPUT
  done

########################  Red Hat  ###########################
echo "getting red hat servers info"
   for rhel_srvrs in `cat $rhel`
   do
echo "$rhel_srvrs" 
ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $rhel_srvrs yum clean all
sub=`ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $rhel_srvrs subscription-manager status |grep Current`
  if [ $? -eq 0 ] ; then
   sub="Registered"
   else
   sub="Not Registered"
   ptchdue=1
  fi
patches=`ssh -o $TIMEOUT -o $NOPWD -o StrictHostKeyChecking=no $rhel_srvrs yum updateinfo list |grep "^RH" |awk '{print $1}' |sort |uniq |wc -l`
 if [ $? -eq 0 ] ; then
   ptchdue=$patches
   else
   ptchdue=0
  fi
echo "$rhel_srvrs $sub $ptchdue"
if [[ $sub == "Not Registered" ]] ; then
   ptchdue=1
  fi

echo "$rhel_srvrs,RHEL,$stat,$sub,$ptchdue" >> $OUTPUT
   done
cp $OUTPUT /opt/scripts/admin/lxpatch/alldiv

sort -k 1 $OUTPUT>$OUTPUT.new
mv $OUTPUT.new $OUTPUT
grep -i itdt $OUTPUT >$OUTPUT.test 
grep -i itdc $OUTPUT >$OUTPUT.cert
grep -i itdp $OUTPUT >$OUTPUT.prod

`$PTH/${div}_patch_web_report.pl`
